package com.examplebr.edu.faculdadealfa.projectfolhaofi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectFolhaOfiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectFolhaOfiApplication.class, args);
	}

}
